/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package autotest;

/**
 *
 * @author ellen futsum
 */
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
public class AutoTest {
/**
* @param args the command line arguments
*/

        public static void main(String[] args) throws InterruptedException {
            System.setProperty("webdriver.chrome.driver", "C:\\Gecko\\chromedriver.exe");
            WebDriver driver;
            ChromeOptions chromeOptions= new ChromeOptions();
            driver=new ChromeDriver(chromeOptions);;
            chromeOptions.addArguments("--headless");
            chromeOptions.addArguments("--no-sandbox");

            String url="https://mail.google.com/";
          driver.get(url);
            String username= "almialmi61621";
            String password= "cybma12345";


            driver.findElement(By.name("identifier")).clear();
            driver.findElement(By.name("identifier")).sendKeys(username,Keys.ENTER);
            Thread.sleep(5000);

            driver.findElement(By.name("password")).clear();
            driver.findElement(By.name("password")).sendKeys(password,Keys.ENTER);
            Thread.sleep(10000);
          
            String Inbox=driver.findElement(By.xpath("//div[@class='bsU']")).getText();
            System.out.println(Inbox);
            driver.quit();
        }

        
}





